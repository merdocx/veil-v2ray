#!/usr/bin/env python3
"""
Глубокая диагностика ключей для выявления проблемы
"""

import sys
import os
import json
import subprocess

sys.path.insert(0, '/root/vpn-server')

from xray_config_manager import xray_config_manager
from storage.sqlite_storage import storage

def deep_compare_keys(uuid1, uuid2):
    """Глубокое сравнение двух ключей"""
    print("="*80)
    print("ГЛУБОКАЯ ДИАГНОСТИКА КЛЮЧЕЙ")
    print("="*80)
    
    config = xray_config_manager._load_config()
    reality_keys = xray_config_manager._load_reality_keys()
    
    key1_inbound = None
    key2_inbound = None
    
    # Находим inbounds для обоих ключей
    for inbound in config.get('inbounds', []):
        if inbound.get('protocol') != 'vless':
            continue
        clients = inbound.get('settings', {}).get('clients', [])
        for client in clients:
            if client.get('id') == uuid1:
                key1_inbound = inbound
            if client.get('id') == uuid2:
                key2_inbound = inbound
    
    print("\n1. СРАВНЕНИЕ КОНФИГУРАЦИЙ XRAY:")
    print("-"*80)
    
    if key1_inbound and key2_inbound:
        print("\nРАБОТАЮЩИЙ КЛЮЧ (9649f6d9...):")
        print(f"  Tag: {key1_inbound.get('tag')}")
        print(f"  Port: {key1_inbound.get('port')}")
        print(f"  Listen: {key1_inbound.get('listen')}")
        
        rs1 = key1_inbound.get('streamSettings', {}).get('realitySettings', {})
        print(f"  Reality Settings:")
        print(f"    - show: {rs1.get('show')}")
        print(f"    - dest: {rs1.get('dest')}")
        print(f"    - xver: {rs1.get('xver')}")
        print(f"    - serverName: {rs1.get('serverName')}")
        print(f"    - serverNames: {rs1.get('serverNames')}")
        print(f"    - privateKey: {rs1.get('privateKey', '')[:30]}...")
        print(f"    - publicKey: {rs1.get('publicKey', 'N/A')}")
        print(f"    - shortIds: {rs1.get('shortIds')}")
        print(f"    - spiderX: {rs1.get('spiderX')}")
        print(f"    - fingerprint: {rs1.get('fingerprint')}")
        print(f"    - maxTimeDiff: {rs1.get('maxTimeDiff')}")
        
        client1 = key1_inbound.get('settings', {}).get('clients', [{}])[0]
        print(f"  Client Settings:")
        print(f"    - id: {client1.get('id')}")
        print(f"    - email: {client1.get('email')}")
        print(f"    - flow: {client1.get('flow')}")
        print(f"    - level: {client1.get('level')}")
        
        print("\nНЕРАБОТАЮЩИЙ КЛЮЧ (b39a9647...):")
        print(f"  Tag: {key2_inbound.get('tag')}")
        print(f"  Port: {key2_inbound.get('port')}")
        print(f"  Listen: {key2_inbound.get('listen')}")
        
        rs2 = key2_inbound.get('streamSettings', {}).get('realitySettings', {})
        print(f"  Reality Settings:")
        print(f"    - show: {rs2.get('show')}")
        print(f"    - dest: {rs2.get('dest')}")
        print(f"    - xver: {rs2.get('xver')}")
        print(f"    - serverName: {rs2.get('serverName')}")
        print(f"    - serverNames: {rs2.get('serverNames')}")
        print(f"    - privateKey: {rs2.get('privateKey', '')[:30]}...")
        print(f"    - publicKey: {rs2.get('publicKey', 'N/A')}")
        print(f"    - shortIds: {rs2.get('shortIds')}")
        print(f"    - spiderX: {rs2.get('spiderX')}")
        print(f"    - fingerprint: {rs2.get('fingerprint')}")
        print(f"    - maxTimeDiff: {rs2.get('maxTimeDiff')}")
        
        client2 = key2_inbound.get('settings', {}).get('clients', [{}])[0]
        print(f"  Client Settings:")
        print(f"    - id: {client2.get('id')}")
        print(f"    - email: {client2.get('email')}")
        print(f"    - flow: {client2.get('flow')}")
        print(f"    - level: {client2.get('level')}")
        
        print("\n" + "="*80)
        print("СРАВНЕНИЕ ПАРАМЕТРОВ:")
        print("="*80)
        
        differences = []
        
        if rs1.get('privateKey') != rs2.get('privateKey'):
            differences.append("❌ privateKey различается")
        else:
            print("✅ privateKey совпадает")
        
        if rs1.get('publicKey') != rs2.get('publicKey'):
            differences.append(f"❌ publicKey различается: '{rs1.get('publicKey')}' vs '{rs2.get('publicKey')}'")
        else:
            print(f"✅ publicKey совпадает: {rs1.get('publicKey')}")
        
        if rs1.get('shortIds') != rs2.get('shortIds'):
            differences.append(f"❌ shortIds различаются: {rs1.get('shortIds')} vs {rs2.get('shortIds')}")
        else:
            print(f"✅ shortIds совпадают")
        
        if rs1.get('serverName') != rs2.get('serverName'):
            differences.append(f"❌ serverName различается: '{rs1.get('serverName')}' vs '{rs2.get('serverName')}'")
        else:
            print(f"✅ serverName совпадает")
        
        if rs1.get('fingerprint') != rs2.get('fingerprint'):
            differences.append(f"❌ fingerprint различается: '{rs1.get('fingerprint')}' vs '{rs2.get('fingerprint')}'")
        else:
            print(f"✅ fingerprint совпадает")
        
        if client1.get('level') != client2.get('level'):
            differences.append(f"❌ client level различается: {client1.get('level')} vs {client2.get('level')}")
        else:
            print(f"✅ client level совпадает")
        
        if differences:
            print("\n⚠️  НАЙДЕНЫ РАЗЛИЧИЯ:")
            for diff in differences:
                print(f"  {diff}")
        else:
            print("\n✅ Все параметры совпадают")
    
    print("\n" + "="*80)
    print("2. ПРОВЕРКА БАЗЫ ДАННЫХ:")
    print("-"*80)
    
    key1_db = storage.get_key_by_identifier(uuid1)
    key2_db = storage.get_key_by_identifier(uuid2)
    
    if key1_db:
        print(f"\nРаботающий ключ в БД:")
        print(f"  - ID: {key1_db.get('id')}")
        print(f"  - Name: {key1_db.get('name')}")
        print(f"  - UUID: {key1_db.get('uuid')}")
        print(f"  - Active: {key1_db.get('is_active')}")
        print(f"  - Port: {key1_db.get('port')}")
        print(f"  - Short ID: {key1_db.get('short_id')}")
        print(f"  - SNI: {key1_db.get('sni')}")
    
    if key2_db:
        print(f"\nНеработающий ключ в БД:")
        print(f"  - ID: {key2_db.get('id')}")
        print(f"  - Name: {key2_db.get('name')}")
        print(f"  - UUID: {key2_db.get('uuid')}")
        print(f"  - Active: {key2_db.get('is_active')}")
        print(f"  - Port: {key2_db.get('port')}")
        print(f"  - Short ID: {key2_db.get('short_id')}")
        print(f"  - SNI: {key2_db.get('sni')}")
    
    print("\n" + "="*80)
    print("3. ПРОВЕРКА CENTRALIZED KEYS:")
    print("-"*80)
    print(f"  Private Key: {reality_keys.get('private_key', 'N/A')[:30]}...")
    print(f"  Public Key: {reality_keys.get('public_key', 'N/A')}")
    print(f"  Short ID: {reality_keys.get('short_id', 'N/A')}")
    
    print("\n" + "="*80)
    print("4. ПРОВЕРКА ПОРТОВ:")
    print("-"*80)
    
    # Проверка, слушает ли Xray на портах
    try:
        result = subprocess.run(['netstat', '-tuln'], capture_output=True, text=True, timeout=5)
        ports_listening = result.stdout
        
        port1 = key1_inbound.get('port') if key1_inbound else None
        port2 = key2_inbound.get('port') if key2_inbound else None
        
        if port1:
            if f":{port1} " in ports_listening:
                print(f"✅ Порт {port1} (работающий ключ) слушается")
            else:
                print(f"❌ Порт {port1} (работающий ключ) НЕ слушается")
        
        if port2:
            if f":{port2} " in ports_listening:
                print(f"✅ Порт {port2} (неработающий ключ) слушается")
            else:
                print(f"❌ Порт {port2} (неработающий ключ) НЕ слушается")
    except Exception as e:
        print(f"⚠️  Не удалось проверить порты: {e}")
    
    print("\n" + "="*80)
    print("5. ПРОВЕРКА ЛОГОВ XRAY:")
    print("-"*80)
    
    log_file = "/root/vpn-server/logs/error.log"
    if os.path.exists(log_file):
        try:
            with open(log_file, 'r') as f:
                lines = f.readlines()
                recent_errors = [l for l in lines[-50:] if ('error' in l.lower() or 'fail' in l.lower()) and (uuid1[:8] in l or uuid2[:8] in l or '10014' in l or '10021' in l)]
                if recent_errors:
                    print("⚠️  Найдены ошибки в логах:")
                    for err in recent_errors[-10:]:
                        print(f"  {err.strip()}")
                else:
                    print("✅ Нет ошибок в логах для этих ключей")
        except Exception as e:
            print(f"⚠️  Не удалось прочитать логи: {e}")
    else:
        print("⚠️  Файл логов не найден")
    
    print("\n" + "="*80)
    print("6. ПРОВЕРКА XRAY API:")
    print("-"*80)
    
    try:
        # Проверяем статус Xray через API
        result = subprocess.run(
            ['/usr/local/bin/xray', 'api', 'statsquery', '--server=127.0.0.1:10808'],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            print("✅ Xray API отвечает")
        else:
            print(f"❌ Xray API не отвечает: {result.stderr}")
    except Exception as e:
        print(f"⚠️  Ошибка при проверке Xray API: {e}")

if __name__ == "__main__":
    uuid1 = "9649f6d9-407a-4038-8500-f00020b3044d"  # Работающий
    uuid2 = "b39a9647-ec86-4c96-ac7c-614e795be3dd"  # Неработающий
    
    deep_compare_keys(uuid1, uuid2)


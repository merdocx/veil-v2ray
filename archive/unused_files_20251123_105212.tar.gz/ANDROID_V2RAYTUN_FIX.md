# Исправление проблемы с Android v2raytun - DNS ошибка

**Проблема:** На Android через v2raytun не работает, пишет "не удается найти DNS адрес сайта"  
**Статус на iOS:** Работает нормально  
**Дата:** 22 ноября 2025

---

## 🔍 Анализ проблемы

### Текущая конфигурация (проверена):
- ✅ `spiderX: "/"` - установлен
- ✅ `fingerprint: "randomized"` - установлен
- ✅ `shortIds: ["8669dcee"]` - 8 символов
- ✅ `dest: "www.microsoft.com:443"`
- ✅ `serverNames: [...]` - массив присутствует
- ❌ **Отсутствует явный `serverName`** (только массив `serverNames`)

---

## ⚠️ Возможные причины проблемы

### 1. Отсутствие явного `serverName` в realitySettings

**Проблема:** Android v2raytun может требовать явный параметр `serverName` в дополнение к массиву `serverNames`.

**Текущая конфигурация:**
```json
"realitySettings": {
    "serverNames": ["www.microsoft.com", ...],  // Только массив
    // serverName отсутствует
}
```

**Рекомендуемая конфигурация:**
```json
"realitySettings": {
    "serverName": "www.microsoft.com",  // Явный параметр
    "serverNames": ["www.microsoft.com", ...],  // Массив
}
```

---

### 2. Проблема с `fingerprint: "randomized"`

**Проблема:** Некоторые версии v2raytun могут не поддерживать `fingerprint: "randomized"`.

**Рекомендация:** Попробовать использовать конкретный fingerprint:
- `"fingerprint": "chrome"` - для Chrome
- `"fingerprint": "firefox"` - для Firefox
- `"fingerprint": "safari"` - для Safari

---

### 3. Проблема с `flow` в клиенте

**Проблема:** Для Reality/TCP может потребоваться явный `flow`.

**Текущая конфигурация:**
```json
"clients": [{
    "id": "uuid",
    "flow": "",  // Пустой
}]
```

**Рекомендация:** Для Reality/TCP обычно `flow` должен быть пустым, но можно попробовать:
- `"flow": "xtls-rprx-vision"` - для XTLS (но это не для Reality)

---

## 🔧 Решения

### Решение 1: Добавить явный `serverName` (ВЫСОКИЙ ПРИОРИТЕТ)

Добавить `serverName` в realitySettings для каждого inbound, используя первый элемент из `serverNames` или SNI из БД.

**Изменение в `xray_config_manager.py`:**
```python
"realitySettings": {
    "serverName": server_names[0] if server_names else "www.microsoft.com",  # Добавить
    "serverNames": server_names,
    ...
}
```

---

### Решение 2: Изменить `fingerprint` на конкретный (СРЕДНИЙ ПРИОРИТЕТ)

Вместо `"randomized"` использовать `"chrome"` для лучшей совместимости с v2raytun.

**Изменение:**
```python
"fingerprint": "chrome",  # Вместо "randomized"
```

---

### Решение 3: Проверить версию v2raytun

Убедиться, что используется последняя версия v2raytun, которая поддерживает Reality протокол.

---

## 📋 Рекомендуемый порядок исправления

1. **Сначала:** Добавить явный `serverName` в realitySettings
2. **Затем:** Если не поможет, изменить `fingerprint` с `"randomized"` на `"chrome"`
3. **Если не поможет:** Проверить версию v2raytun и обновить приложение

---

## 🔍 Дополнительная диагностика

### Проверка VLESS ссылки:
```
vless://9649f6d9-407a-4038-8500-f00020b3044d@veil-bird.ru:10014?type=tcp&security=reality&sni=www.microsoft.com&pbk=eeA7CJSPNzlYKqXAsRfFNwtcpG2wXOtgDLPqaXBV13c&sid=8669dcee&fp=randomized
```

**Параметры:**
- ✅ `sid=8669dcee` - 8 символов, правильно
- ✅ `fp=randomized` - установлен
- ✅ `sni=www.microsoft.com` - установлен
- ✅ `type=tcp` - правильно
- ✅ `security=reality` - правильно

**Возможная проблема:** v2raytun может не поддерживать `fp=randomized` или требовать явный `serverName` в конфигурации сервера.

---

**Статус:** Требуется добавить `serverName` в конфигурацию Xray


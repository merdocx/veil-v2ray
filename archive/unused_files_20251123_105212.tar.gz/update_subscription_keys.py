#!/usr/bin/env python3
"""
Скрипт для обновления ключей, привязанных к подпискам (с email адресами)
Обновляет short_id до 8 символов для Android совместимости
"""

import sys
import os
import sqlite3
import logging
from typing import List, Dict

# Добавляем путь к модулям
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from storage.sqlite_storage import storage
from xray_config_manager import xray_config_manager, sync_short_ids_from_db

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/root/vpn-server/logs/update_subscription_keys.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def is_subscription_key(name: str) -> bool:
    """Проверка, является ли ключ привязанным к подписке (имеет email адрес)"""
    # Ключи с подписками имеют формат: *@domain.com или *@mail.ru и т.д.
    return '@' in name and '.' in name.split('@')[1] if '@' in name else False

def truncate_short_id(short_id: str, target_length: int = 8) -> str:
    """Обрезает short_id до указанной длины"""
    if not short_id:
        return short_id
    if len(short_id) > target_length:
        return short_id[:target_length]
    return short_id

def update_subscription_keys() -> Dict:
    """Обновление short_id для ключей с подписками"""
    logger.info("=== Обновление ключей с подписками ===")
    
    try:
        # Получаем все ключи
        all_keys = storage.get_all_keys()
        logger.info(f"Всего ключей в базе: {len(all_keys)}")
        
        # Фильтруем ключи с подписками
        subscription_keys = [k for k in all_keys if is_subscription_key(k.get('name', ''))]
        logger.info(f"Найдено ключей с подписками: {len(subscription_keys)}")
        
        updated_keys = []
        skipped_keys = []
        error_keys = []
        
        for key in subscription_keys:
            try:
                key_uuid = key.get('uuid')
                key_name = key.get('name', 'unknown')
                current_short_id = key.get('short_id')
                
                if not key_uuid:
                    logger.warning(f"Ключ {key_name} не имеет UUID, пропускаем")
                    skipped_keys.append(key_name)
                    continue
                
                if not current_short_id:
                    logger.warning(f"Ключ {key_name} не имеет short_id, пропускаем")
                    skipped_keys.append(key_name)
                    continue
                
                # Проверяем длину short_id
                if len(current_short_id) == 8:
                    logger.info(f"Ключ {key_name} уже имеет short_id длиной 8 символов: {current_short_id}")
                    skipped_keys.append(key_name)
                    continue
                
                # Обрезаем short_id до 8 символов
                new_short_id = truncate_short_id(current_short_id, 8)
                
                if new_short_id == current_short_id:
                    logger.info(f"Ключ {key_name} не требует обновления")
                    skipped_keys.append(key_name)
                    continue
                
                logger.info(f"Обновление ключа {key_name}: {current_short_id} ({len(current_short_id)} символов) -> {new_short_id} (8 символов)")
                
                # Обновляем short_id в базе данных
                # Получаем данные ключа для проверки существования
                key_data = storage.get_key_by_identifier(key_uuid)
                if not key_data:
                    logger.error(f"Ключ {key_uuid} не найден в базе")
                    error_keys.append(key_name)
                    continue
                
                # Обновляем только short_id через update_key_fields
                storage.update_key_fields(key_uuid, short_id=new_short_id)
                
                updated_keys.append({
                    'name': key_name,
                    'uuid': key_uuid,
                    'old_short_id': current_short_id,
                    'new_short_id': new_short_id
                })
                
                logger.info(f"✅ Обновлен short_id для ключа {key_name}")
                
            except Exception as e:
                logger.error(f"Ошибка обновления ключа {key.get('name', 'unknown')}: {e}")
                error_keys.append(key.get('name', 'unknown'))
        
        logger.info(f"\n=== Результаты обновления ===")
        logger.info(f"Обновлено ключей: {len(updated_keys)}")
        logger.info(f"Пропущено ключей: {len(skipped_keys)}")
        logger.info(f"Ошибок: {len(error_keys)}")
        
        if updated_keys:
            logger.info("\nОбновленные ключи:")
            for key_info in updated_keys:
                logger.info(f"  - {key_info['name']}: {key_info['old_short_id']} -> {key_info['new_short_id']}")
        
        # Синхронизируем short_id из БД в конфигурацию Xray
        logger.info("\n=== Синхронизация конфигурации Xray ===")
        sync_result = sync_short_ids_from_db()
        
        if sync_result.get('status') == 'success':
            fixed_count = sync_result.get('fixed_count', 0)
            logger.info(f"✅ Синхронизировано {fixed_count} short_id в конфигурации Xray")
        else:
            logger.warning(f"⚠️ Проблемы при синхронизации: {sync_result.get('error', 'unknown error')}")
        
        return {
            'status': 'success',
            'updated_count': len(updated_keys),
            'skipped_count': len(skipped_keys),
            'error_count': len(error_keys),
            'updated_keys': updated_keys,
            'sync_result': sync_result
        }
        
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }

if __name__ == '__main__':
    result = update_subscription_keys()
    
    if result.get('status') == 'success':
        print(f"\n✅ Обновление завершено успешно")
        print(f"   Обновлено: {result.get('updated_count', 0)}")
        print(f"   Пропущено: {result.get('skipped_count', 0)}")
        print(f"   Ошибок: {result.get('error_count', 0)}")
        sys.exit(0)
    else:
        print(f"\n❌ Ошибка обновления: {result.get('error', 'unknown')}")
        sys.exit(1)


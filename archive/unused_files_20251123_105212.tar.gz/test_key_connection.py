#!/usr/bin/env python3
"""
Тест подключения к ключам
"""

import sys
import socket
import subprocess

sys.path.insert(0, '/root/vpn-server')

from xray_config_manager import xray_config_manager

def test_port_connection(host, port):
    """Тест подключения к порту"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception as e:
        print(f"Ошибка при тесте порта {port}: {e}")
        return False

def check_xray_inbound(uuid):
    """Проверка, загружен ли inbound в Xray через API"""
    try:
        # Пытаемся получить статистику для ключа
        result = subprocess.run(
            ['/usr/local/bin/xray', 'api', 'statsquery', 
             '--server=127.0.0.1:10808',
             '-pattern', f'user>>>{uuid}'],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.returncode == 0
    except Exception as e:
        print(f"Ошибка при проверке через API: {e}")
        return False

def test_keys():
    """Тест обоих ключей"""
    print("="*80)
    print("ТЕСТ ПОДКЛЮЧЕНИЯ К КЛЮЧАМ")
    print("="*80)
    
    uuid1 = "9649f6d9-407a-4038-8500-f00020b3044d"  # Работающий
    uuid2 = "b39a9647-ec86-4c96-ac7c-614e795be3dd"  # Неработающий
    
    config = xray_config_manager._load_config()
    
    # Находим порты
    port1 = None
    port2 = None
    
    for inbound in config.get('inbounds', []):
        if inbound.get('protocol') != 'vless':
            continue
        clients = inbound.get('settings', {}).get('clients', [])
        for client in clients:
            if client.get('id') == uuid1:
                port1 = inbound.get('port')
            if client.get('id') == uuid2:
                port2 = inbound.get('port')
    
    print(f"\n1. Тест портов:")
    print(f"   Порт 10014 (работающий): {'✅ Открыт' if test_port_connection('127.0.0.1', 10014) else '❌ Закрыт'}")
    print(f"   Порт 10021 (неработающий): {'✅ Открыт' if test_port_connection('127.0.0.1', 10021) else '❌ Закрыт'}")
    
    print(f"\n2. Проверка через Xray API:")
    print(f"   Ключ 9649f6d9...: {'✅ Найден в Xray' if check_xray_inbound(uuid1) else '❌ Не найден в Xray'}")
    print(f"   Ключ b39a9647...: {'✅ Найден в Xray' if check_xray_inbound(uuid2) else '❌ Не найден в Xray'}")
    
    print(f"\n3. Рекомендация:")
    print("   Если порты открыты, но ключ не работает, возможно нужно:")
    print("   - Перезагрузить Xray: systemctl restart xray")
    print("   - Проверить, что конфигурация применена через API")

if __name__ == "__main__":
    test_keys()


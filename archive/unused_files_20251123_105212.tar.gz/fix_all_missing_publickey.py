#!/usr/bin/env python3
"""
Скрипт для исправления всех ключей без publicKey
"""

import sys
import os

sys.path.insert(0, '/root/vpn-server')

from xray_config_manager import xray_config_manager
from storage.sqlite_storage import storage

def fix_all_missing_publickey():
    """Исправление всех ключей без publicKey"""
    print("Поиск и исправление ключей без publicKey...\n")
    
    # Загружаем Reality ключи
    reality_keys = xray_config_manager._load_reality_keys()
    public_key = reality_keys.get('public_key')
    
    if not public_key:
        print("✗ Ошибка: не найден публичный ключ в keys.env")
        return False
    
    print(f"Публичный ключ: {public_key}\n")
    
    # Загружаем конфигурацию
    config = xray_config_manager._load_config()
    if not config:
        print("✗ Ошибка: не удалось загрузить конфигурацию")
        return False
    
    fixed_count = 0
    fixed_keys = []
    
    # Ищем все ключи без publicKey
    for inbound in config.get('inbounds', []):
        if inbound.get('protocol') != 'vless':
            continue
            
        reality_settings = inbound.get('streamSettings', {}).get('realitySettings', {})
        if not reality_settings:
            continue
            
        if not reality_settings.get('publicKey'):
            clients = inbound.get('settings', {}).get('clients', [])
            for client in clients:
                uuid = client.get('id')
                if uuid:
                    reality_settings['publicKey'] = public_key
                    fixed_count += 1
                    fixed_keys.append((uuid, inbound.get('tag', '')))
                    print(f"✓ Исправлен ключ: {uuid[:8]}... (tag: {inbound.get('tag', '')})")
    
    if fixed_count == 0:
        print("✓ Все ключи уже имеют publicKey")
        return True
    
    print(f"\nИсправлено ключей: {fixed_count}")
    
    # Сохраняем конфигурацию
    if xray_config_manager._save_config(config):
        print("✓ Конфигурация сохранена")
        
        # Перезагружаем Xray для применения изменений
        print("\nПрименение изменений через Xray API...")
        for uuid, tag in fixed_keys:
            for inbound in config.get('inbounds', []):
                if inbound.get('tag') == tag:
                    if xray_config_manager._apply_inbound_via_api(inbound):
                        print(f"  ✓ Применен inbound для {uuid[:8]}...")
                    break
        
        print("\n✓ Все ключи исправлены успешно!")
        return True
    else:
        print("✗ Ошибка при сохранении конфигурации")
        return False

if __name__ == "__main__":
    if fix_all_missing_publickey():
        print("\n✅ Готово!")
    else:
        print("\n✗ Произошла ошибка")
        sys.exit(1)


#!/usr/bin/env python3
"""
Скрипт для детальной проверки конкретных ключей
"""

import sys
import os
import json
import subprocess
from urllib.parse import urlparse, parse_qs

sys.path.insert(0, '/root/vpn-server')

from storage.sqlite_storage import storage
from xray_config_manager import xray_config_manager
from xray_stats_reader import get_xray_user_traffic

def parse_vless_url(url):
    """Парсинг VLESS URL"""
    parsed = urlparse(url)
    uuid = parsed.username
    host = parsed.hostname
    port = parsed.port
    params = parse_qs(parsed.query)
    name = parsed.fragment  # Имя после #
    
    return {
        'uuid': uuid,
        'host': host,
        'port': port,
        'type': params.get('type', [''])[0],
        'security': params.get('security', [''])[0],
        'encryption': params.get('encryption', [''])[0],
        'fp': params.get('fp', [''])[0],
        'pbk': params.get('pbk', [''])[0],
        'sid': params.get('sid', [''])[0],
        'sni': params.get('sni', [''])[0],
        'name': name
    }

def check_key_details(uuid, port=None):
    """Проверка деталей ключа"""
    print(f"\n{'='*80}")
    print(f"ПРОВЕРКА КЛЮЧА: {uuid}")
    print(f"{'='*80}\n")
    
    # Проверка в базе данных
    print("1. Проверка в базе данных:")
    key = storage.get_key_by_identifier(uuid)
    if key:
        print(f"   ✓ Найден в БД")
        print(f"   - ID: {key.get('id')}")
        print(f"   - Name: {key.get('name')}")
        print(f"   - UUID: {key.get('uuid')}")
        print(f"   - Active: {key.get('is_active')}")
        print(f"   - Port: {key.get('port')}")
        print(f"   - Short ID: {key.get('short_id')}")
        print(f"   - SNI: {key.get('sni')}")
        print(f"   - Created: {key.get('created_at')}")
    else:
        print(f"   ✗ НЕ НАЙДЕН в БД")
        return None
    
    # Проверка в конфигурации Xray
    print("\n2. Проверка в конфигурации Xray:")
    config = xray_config_manager._load_config()
    if config and 'inbounds' in config:
        found_in_config = False
        for inbound in config.get('inbounds', []):
            clients = inbound.get('settings', {}).get('clients', [])
            for client in clients:
                if client.get('id') == uuid:
                    found_in_config = True
                    print(f"   ✓ Найден в конфигурации Xray")
                    print(f"   - Inbound tag: {inbound.get('tag', 'N/A')}")
                    print(f"   - Inbound port: {inbound.get('port', 'N/A')}")
                    print(f"   - Client email: {client.get('email', 'N/A')}")
                    
                    # Проверка Reality настроек
                    stream_settings = inbound.get('streamSettings', {})
                    reality_settings = stream_settings.get('realitySettings', {})
                    if reality_settings:
                        print(f"   - Reality settings:")
                        print(f"     * Server names: {reality_settings.get('serverNames', [])}")
                        print(f"     * Public key: {reality_settings.get('publicKey', 'N/A')}")
                        print(f"     * Short IDs: {reality_settings.get('shortIds', [])}")
                        print(f"     * Private key: {reality_settings.get('privateKey', 'N/A')[:20]}...")
                    
                    # Проверка порта
                    if port and inbound.get('port') != port:
                        print(f"   ⚠️  ВНИМАНИЕ: Порт в URL ({port}) не совпадает с портом inbound ({inbound.get('port')})")
                    
                    break
            if found_in_config:
                break
        
        if not found_in_config:
            print(f"   ✗ НЕ НАЙДЕН в конфигурации Xray")
    else:
        print(f"   ✗ Не удалось загрузить конфигурацию Xray")
    
    # Проверка трафика
    print("\n3. Проверка трафика:")
    try:
        traffic = get_xray_user_traffic(uuid)
        if traffic and traffic.get('total', 0) > 0:
            print(f"   ✓ Есть трафик:")
            print(f"     - Uplink: {traffic.get('uplink', 0)} bytes")
            print(f"     - Downlink: {traffic.get('downlink', 0)} bytes")
            print(f"     - Total: {traffic.get('total', 0)} bytes")
        else:
            print(f"   - Нет трафика (ключ не использовался или неактивен)")
    except Exception as e:
        print(f"   ⚠️  Ошибка при получении трафика: {e}")
    
    # Проверка порта в port_manager
    print("\n4. Проверка порта:")
    from port_manager import get_port_for_key
    assigned_port = get_port_for_key(uuid)
    if assigned_port:
        print(f"   - Назначенный порт: {assigned_port}")
        if port and assigned_port != port:
            print(f"   ⚠️  ВНИМАНИЕ: Порт в URL ({port}) не совпадает с назначенным портом ({assigned_port})")
    else:
        print(f"   ⚠️  Порт не назначен в port_manager")
    
    return key

def compare_keys(url1, url2):
    """Сравнение двух ключей"""
    print("="*80)
    print("СРАВНЕНИЕ ДВУХ КЛЮЧЕЙ")
    print("="*80)
    
    key1_data = parse_vless_url(url1)
    key2_data = parse_vless_url(url2)
    
    print("\nКЛЮЧ 1 (работающий):")
    print(f"  UUID: {key1_data['uuid']}")
    print(f"  Port: {key1_data['port']}")
    print(f"  Short ID: {key1_data['sid']}")
    print(f"  SNI: {key1_data['sni']}")
    print(f"  Name: {key1_data['name']}")
    
    print("\nКЛЮЧ 2 (неработающий):")
    print(f"  UUID: {key2_data['uuid']}")
    print(f"  Port: {key2_data['port']}")
    print(f"  Short ID: {key2_data['sid']}")
    print(f"  SNI: {key2_data['sni']}")
    print(f"  Name: {key2_data['name']}")
    
    print("\nСРАВНЕНИЕ ПАРАМЕТРОВ:")
    print(f"  Host: {'✓ Совпадает' if key1_data['host'] == key2_data['host'] else '✗ Различается'}")
    print(f"  Type: {'✓ Совпадает' if key1_data['type'] == key2_data['type'] else '✗ Различается'}")
    print(f"  Security: {'✓ Совпадает' if key1_data['security'] == key2_data['security'] else '✗ Различается'}")
    print(f"  Encryption: {'✓ Совпадает' if key1_data['encryption'] == key2_data['encryption'] else '✗ Различается'}")
    print(f"  FP: {'✓ Совпадает' if key1_data['fp'] == key2_data['fp'] else '✗ Различается'}")
    print(f"  PBK: {'✓ Совпадает' if key1_data['pbk'] == key2_data['pbk'] else '✗ Различается'}")
    print(f"  SNI: {'✓ Совпадает' if key1_data['sni'] == key2_data['sni'] else '✗ Различается'}")
    print(f"  Short ID: {'✓ Совпадает' if key1_data['sid'] == key2_data['sid'] else '✗ Различается'}")
    print(f"  Name в URL: {'✓ Оба есть' if key1_data['name'] and key2_data['name'] else '✗ Различается (один есть, другой нет)'}")
    
    # Проверка ключей в системе
    print("\n" + "="*80)
    key1 = check_key_details(key1_data['uuid'], key1_data['port'])
    print("\n" + "="*80)
    key2 = check_key_details(key2_data['uuid'], key2_data['port'])
    
    # Дополнительная проверка конфигурации
    print("\n" + "="*80)
    print("ПРОВЕРКА КОНФИГУРАЦИИ XRAY")
    print("="*80)
    
    config = xray_config_manager._load_config()
    if config and 'inbounds' in config:
        print(f"\nВсего inbounds: {len(config.get('inbounds', []))}")
        
        # Поиск inbounds для этих ключей
        for inbound in config.get('inbounds', []):
            clients = inbound.get('settings', {}).get('clients', [])
            for client in clients:
                client_uuid = client.get('id')
                if client_uuid in [key1_data['uuid'], key2_data['uuid']]:
                    print(f"\nInbound для {client_uuid}:")
                    print(f"  Tag: {inbound.get('tag')}")
                    print(f"  Port: {inbound.get('port')}")
                    print(f"  Protocol: {inbound.get('protocol')}")
                    
                    stream = inbound.get('streamSettings', {})
                    reality = stream.get('realitySettings', {})
                    if reality:
                        print(f"  Reality serverNames: {reality.get('serverNames')}")
                        print(f"  Reality publicKey: {reality.get('publicKey', '')[:30]}...")
                        print(f"  Reality shortIds: {reality.get('shortIds')}")
                        
                        # Проверка, есть ли short_id ключа в списке
                        if client_uuid == key1_data['uuid']:
                            expected_sid = key1_data['sid']
                        else:
                            expected_sid = key2_data['sid']
                        
                        if expected_sid in reality.get('shortIds', []):
                            print(f"  ✓ Short ID {expected_sid} присутствует в списке")
                        else:
                            print(f"  ✗ Short ID {expected_sid} ОТСУТСТВУЕТ в списке!")
                            print(f"     Доступные Short IDs: {reality.get('shortIds')}")

if __name__ == "__main__":
    # Работающий ключ
    working_key = "vless://9649f6d9-407a-4038-8500-f00020b3044d@veil-bird.ru:10014?type=tcp&security=reality&encryption=none&fp=chrome&pbk=eeA7CJSPNzlYKqXAsRfFNwtcpG2wXOtgDLPqaXBV13c&sid=8669dcee&sni=www.microsoft.com"
    
    # Неработающий ключ
    non_working_key = "vless://b39a9647-ec86-4c96-ac7c-614e795be3dd@veil-bird.ru:10021?type=tcp&security=reality&encryption=none&fp=chrome&pbk=eeA7CJSPNzlYKqXAsRfFNwtcpG2wXOtgDLPqaXBV13c&sid=8b69ded1&sni=www.microsoft.com#Нидерланды"
    
    compare_keys(working_key, non_working_key)


# Как генерируются конфигурации ключей

**Дата:** 2025-11-23  
**Версия:** 2.3.4

---

## 📋 Обзор процесса генерации

При создании ключа генерируются две конфигурации:
1. **Конфигурация Xray (inbound)** - для сервера
2. **VLESS URL** - для клиента

---

## 🔑 Что УНИКАЛЬНО для каждого ключа

### 1. UUID (уникальный идентификатор)
- **Где:** В конфигурации Xray и в URL
- **Генерация:** `uuid.uuid4()` - случайный UUID v4
- **Пример:** `9649f6d9-407a-4038-8500-f00020b3044d`
- **Использование:**
  - В Xray: `clients[0].id = uuid`
  - В URL: `vless://{uuid}@server...`
  - В БД: сохраняется как основной идентификатор

**Код:** `api.py`, строка 364

---

### 2. Short ID (индивидуальный идентификатор Reality)
- **Где:** В конфигурации Xray (realitySettings.shortIds) и в URL
- **Генерация:** `secrets.token_hex(4)` - 8 hex символов (4 байта)
- **Пример:** `8669dcee`, `8b69ded1`
- **Проверка уникальности:** До 10 попыток генерации
- **Использование:**
  - В Xray: `realitySettings.shortIds = [short_id]`
  - В URL: `sid={short_id}`
  - В БД: сохраняется для каждого ключа

**Код:** `api.py`, строки 366-378

**Важно:** Short ID используется Reality протоколом для разделения пользователей. Каждый ключ имеет свой уникальный short_id.

---

### 3. Порт (уникальный порт для каждого ключа)
- **Где:** В конфигурации Xray (inbound.port) и в URL
- **Генерация:** Автоматически назначается из диапазона 10001-10100
- **Пример:** `10014`, `10021`, `10025`
- **Проверка:** Проверяется доступность порта перед назначением
- **Использование:**
  - В Xray: `inbound.port = assigned_port`
  - В URL: `vless://...@server:{port}...`
  - В БД: сохраняется для каждого ключа

**Код:** `api.py`, строка 399, `port_manager.py`

**Важно:** Каждый ключ получает свой уникальный порт для изоляции трафика.

---

### 4. Имя ключа (name)
- **Где:** В БД и в URL (как фрагмент)
- **Генерация:** Передается пользователем при создании
- **Пример:** `Нидерланды`, `user@example.com`
- **Использование:**
  - В БД: `keys.name`
  - В URL: `vless://...#{key_name}` (метка для клиента)
  - Не влияет на работу VPN, только для удобства

**Код:** `api.py`, строка 383, `generate_client_config.py`, строка 84

---

### 5. Tag inbound (уникальный тег для Xray)
- **Где:** В конфигурации Xray
- **Генерация:** `inbound-{uuid}`
- **Пример:** `inbound-9649f6d9-407a-4038-8500-f00020b3044d`
- **Использование:**
  - В Xray: для идентификации inbound
  - Для управления через Xray API

**Код:** `xray_config_manager.py`, строка 296

---

### 6. Email клиента (в Xray)
- **Где:** В конфигурации Xray
- **Генерация:** Равен UUID ключа
- **Пример:** `9649f6d9-407a-4038-8500-f00020b3044d`
- **Использование:**
  - В Xray: `clients[0].email = uuid`
  - Для идентификации клиента в статистике

**Код:** `xray_config_manager.py`, строка 273

---

## 🌐 Что УНИВЕРСАЛЬНО для всех ключей

### 1. Reality Private Key (приватный ключ)
- **Где:** В конфигурации Xray (realitySettings.privateKey)
- **Источник:** `/root/vpn-server/config/keys.env` → `PRIVATE_KEY`
- **Значение:** `INDgW1I7I-ZmXvEg6pnQR15AfuHT4JlxzIouqIJ5kVs`
- **Использование:** Один приватный ключ для всех ключей (централизованный)

**Код:** `xray_config_manager.py`, строка 288

**Важно:** Приватный ключ общий для всех, так как Reality использует централизованную пару ключей.

---

### 2. Reality Public Key (публичный ключ)
- **Где:** В конфигурации Xray (realitySettings.publicKey) и в URL
- **Источник:** `/root/vpn-server/config/keys.env` → `PUBLIC_KEY`
- **Значение:** `eeA7CJSPNzlYKqXAsRfFNwtcpG2wXOtgDLPqaXBV13c`
- **Использование:**
  - В Xray: `realitySettings.publicKey`
  - В URL: `pbk={public_key}`

**Код:** `xray_config_manager.py`, строка 289, `generate_client_config.py`, строка 66

**Важно:** Публичный ключ общий для всех ключей и передается клиенту в URL.

---

### 3. Server Name (SNI)
- **Где:** В конфигурации Xray (realitySettings.serverName) и в URL
- **Значение:** `www.microsoft.com` (фиксированный для всех)
- **Использование:**
  - В Xray: `realitySettings.serverName = "www.microsoft.com"`
  - В URL: `sni=www.microsoft.com`

**Код:** `api.py`, строка 396, `xray_config_manager.py`, строка 261, `generate_client_config.py`, строка 58

**Важно:** Фиксированный SNI для совместимости с iOS и Android.

---

### 4. Server Names (список допустимых SNI)
- **Где:** В конфигурации Xray (realitySettings.serverNames)
- **Значение:** Список из 8 доменов:
  ```python
  [
      "www.microsoft.com",
      "www.cloudflare.com",
      "www.google.com",
      "www.github.com",
      "www.apple.com",
      "www.facebook.com",
      "www.adobe.com",
      "www.instagram.com"
  ]
  ```
- **Использование:** Общий список для всех ключей

**Код:** `xray_config_manager.py`, строки 249-258

---

### 5. Fingerprint
- **Где:** В конфигурации Xray (realitySettings.fingerprint) и в URL
- **Значение:** `chrome` (фиксированный для всех)
- **Использование:**
  - В Xray: `realitySettings.fingerprint = "chrome"`
  - В URL: `fp=chrome`

**Код:** `xray_config_manager.py`, строка 292, `generate_client_config.py`, строка 84

**Важно:** Фиксированный fingerprint для лучшей совместимости с v2raytun на Android.

---

### 6. Network Type
- **Где:** В конфигурации Xray (streamSettings.network) и в URL
- **Значение:** `tcp` (фиксированный для всех)
- **Использование:**
  - В Xray: `streamSettings.network = "tcp"`
  - В URL: `type=tcp`

**Код:** `xray_config_manager.py`, строка 280, `generate_client_config.py`, строка 84

---

### 7. Security Type
- **Где:** В конфигурации Xray (streamSettings.security) и в URL
- **Значение:** `reality` (фиксированный для всех)
- **Использование:**
  - В Xray: `streamSettings.security = "reality"`
  - В URL: `security=reality`

**Код:** `xray_config_manager.py`, строка 281, `generate_client_config.py`, строка 84

---

### 8. Encryption
- **Где:** В URL
- **Значение:** `none` (фиксированный для всех)
- **Использование:** В URL: `encryption=none`

**Код:** `generate_client_config.py`, строка 84

---

### 9. Destination (dest)
- **Где:** В конфигурации Xray (realitySettings.dest)
- **Значение:** `www.microsoft.com:443` (фиксированный для всех)
- **Использование:** В Xray: `realitySettings.dest = "www.microsoft.com:443"`

**Код:** `xray_config_manager.py`, строка 284

---

### 10. SpiderX
- **Где:** В конфигурации Xray (realitySettings.spiderX)
- **Значение:** `/` (фиксированный для всех)
- **Использование:** В Xray: `realitySettings.spiderX = "/"`

**Код:** `xray_config_manager.py`, строка 291

---

### 11. Max Time Diff
- **Где:** В конфигурации Xray (realitySettings.maxTimeDiff)
- **Значение:** `600` секунд (фиксированный для всех)
- **Использование:** В Xray: `realitySettings.maxTimeDiff = 600`

**Код:** `xray_config_manager.py`, строка 293

---

### 12. Client Level
- **Где:** В конфигурации Xray (clients[0].level)
- **Значение:** `1` (фиксированный для всех)
- **Использование:** В Xray: `clients[0].level = 1`

**Код:** `xray_config_manager.py`, строка 274

**Важно:** Явно установлен для совместимости с Android.

---

### 13. Server Domain
- **Где:** В URL
- **Значение:** `veil-bird.ru` (фиксированный для всех)
- **Использование:** В URL: `vless://...@veil-bird.ru:port...`

**Код:** `generate_client_config.py`, строка 76

---

### 14. Listen Address
- **Где:** В конфигурации Xray (inbound.listen)
- **Значение:** `0.0.0.0` (фиксированный для всех)
- **Использование:** В Xray: `inbound.listen = "0.0.0.0"`

**Код:** `xray_config_manager.py`, строка 265

---

## 📊 Сравнительная таблица

| Параметр | Уникально | Универсально | Где используется |
|----------|-----------|--------------|------------------|
| UUID | ✅ | ❌ | Xray, URL, БД |
| Short ID | ✅ | ❌ | Xray, URL, БД |
| Порт | ✅ | ❌ | Xray, URL, БД |
| Имя ключа | ✅ | ❌ | БД, URL (метка) |
| Tag inbound | ✅ | ❌ | Xray |
| Email клиента | ✅ | ❌ | Xray |
| Private Key | ❌ | ✅ | Xray |
| Public Key | ❌ | ✅ | Xray, URL |
| Server Name (SNI) | ❌ | ✅ | Xray, URL |
| Server Names (список) | ❌ | ✅ | Xray |
| Fingerprint | ❌ | ✅ | Xray, URL |
| Network Type | ❌ | ✅ | Xray, URL |
| Security Type | ❌ | ✅ | Xray, URL |
| Encryption | ❌ | ✅ | URL |
| Destination | ❌ | ✅ | Xray |
| SpiderX | ❌ | ✅ | Xray |
| Max Time Diff | ❌ | ✅ | Xray |
| Client Level | ❌ | ✅ | Xray |
| Server Domain | ❌ | ✅ | URL |
| Listen Address | ❌ | ✅ | Xray |

---

## 🔄 Процесс генерации конфигурации

### Шаг 1: Создание ключа (api.py)

1. **Генерация UUID** → уникальный
2. **Генерация short_id** → уникальный (с проверкой)
3. **Выбор SNI** → универсальный (`www.microsoft.com`)
4. **Назначение порта** → уникальный
5. **Сохранение в БД** → все уникальные параметры

### Шаг 2: Создание inbound для Xray (xray_config_manager.py)

1. **Загрузка Reality ключей** → универсальные (из `keys.env`)
2. **Создание inbound**:
   - Уникальные: UUID, порт, short_id, tag
   - Универсальные: все остальные параметры Reality

### Шаг 3: Генерация URL для клиента (generate_client_config.py)

1. **Поиск inbound** по UUID
2. **Извлечение параметров**:
   - Уникальные: UUID, порт, short_id
   - Универсальные: public_key, SNI, fingerprint, и т.д.
3. **Формирование URL** с кодировкой UTF-8

---

## 🎯 Ключевые особенности

### Почему некоторые параметры универсальны?

1. **Reality ключи (private/public):**
   - Reality протокол использует централизованную пару ключей
   - Все ключи используют одну пару для безопасности

2. **SNI и Server Names:**
   - Фиксированные для совместимости с iOS и Android
   - Упрощает конфигурацию клиентов

3. **Fingerprint:**
   - Фиксированный `chrome` для лучшей работы с v2raytun на Android

### Почему некоторые параметры уникальны?

1. **UUID:**
   - Уникальный идентификатор каждого пользователя
   - Используется для аутентификации

2. **Short ID:**
   - Разделяет пользователей в Reality протоколе
   - Каждый ключ имеет свой short_id для изоляции

3. **Порт:**
   - Изолирует трафик каждого пользователя
   - Упрощает мониторинг и управление

---

## ✅ Итог

**Уникально для каждого ключа (6 параметров):**
- UUID
- Short ID
- Порт
- Имя ключа
- Tag inbound
- Email клиента

**Универсально для всех ключей (14 параметров):**
- Reality Private Key
- Reality Public Key
- Server Name (SNI)
- Server Names (список)
- Fingerprint
- Network Type
- Security Type
- Encryption
- Destination
- SpiderX
- Max Time Diff
- Client Level
- Server Domain
- Listen Address

**Итого:** 6 уникальных + 14 универсальных = 20 параметров в конфигурации

---

**Дата создания:** 2025-11-23  
**Версия документа:** 1.0


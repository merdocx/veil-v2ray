#!/usr/bin/env python3
"""
Сравнение URL ключей для выявления различий
"""

from urllib.parse import urlparse, parse_qs

url1 = "vless://9649f6d9-407a-4038-8500-f00020b3044d@veil-bird.ru:10014?type=tcp&security=reality&encryption=none&fp=chrome&pbk=eeA7CJSPNzlYKqXAsRfFNwtcpG2wXOtgDLPqaXBV13c&sid=8669dcee&sni=www.microsoft.com"

url2 = "vless://b39a9647-ec86-4c96-ac7c-614e795be3dd@veil-bird.ru:10021?type=tcp&security=reality&encryption=none&fp=chrome&pbk=eeA7CJSPNzlYKqXAsRfFNwtcpG2wXOtgDLPqaXBV13c&sid=8b69ded1&sni=www.microsoft.com"

def parse_vless_url(url):
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    
    return {
        'uuid': parsed.username,
        'host': parsed.hostname,
        'port': parsed.port,
        'type': params.get('type', [''])[0],
        'security': params.get('security', [''])[0],
        'encryption': params.get('encryption', [''])[0],
        'fp': params.get('fp', [''])[0],
        'pbk': params.get('pbk', [''])[0],
        'sid': params.get('sid', [''])[0],
        'sni': params.get('sni', [''])[0],
        'name': parsed.fragment
    }

print("="*80)
print("СРАВНЕНИЕ URL КЛЮЧЕЙ")
print("="*80)

key1 = parse_vless_url(url1)
key2 = parse_vless_url(url2)

print("\nРАБОТАЮЩИЙ КЛЮЧ:")
for k, v in key1.items():
    print(f"  {k}: {v}")

print("\nНЕРАБОТАЮЩИЙ КЛЮЧ:")
for k, v in key2.items():
    print(f"  {k}: {v}")

print("\n" + "="*80)
print("РАЗЛИЧИЯ:")
print("="*80)

differences = []
for k in key1.keys():
    if key1[k] != key2[k]:
        differences.append(f"  ❌ {k}: '{key1[k]}' vs '{key2[k]}'")
    else:
        print(f"  ✅ {k}: совпадает")

if differences:
    print("\n⚠️  НАЙДЕНЫ РАЗЛИЧИЯ:")
    for diff in differences:
        print(diff)
else:
    print("\n✅ Все параметры URL совпадают (кроме UUID, порта и shortId, что нормально)")


#!/usr/bin/env python3
"""
Тесты для проверки корректности генерации VPN ключей
Проверяет:
1. Формат VLESS URL
2. Наличие всех обязательных параметров
3. Корректность fingerprint (должен быть randomized)
4. Соответствие конфигурации Xray и генерируемого URL
"""

import sys
import os
import json
import re

# Добавляем путь к проекту
sys.path.insert(0, '/root/vpn-server')

from generate_client_config import generate_client_config
from storage.sqlite_storage import storage
from xray_config_manager import xray_config_manager

def test_vless_url_format(url: str) -> tuple[bool, str]:
    """Проверка формата VLESS URL"""
    if not url.startswith('vless://'):
        return False, "URL должен начинаться с 'vless://'"
    
    # Проверяем структуру: vless://uuid@host:port?params#name
    pattern = r'vless://([^@]+)@([^:]+):(\d+)\?([^#]+)#(.+)'
    match = re.match(pattern, url)
    if not match:
        return False, "Неверный формат URL"
    
    uuid, host, port, params, name = match.groups()
    
    # Проверяем UUID формат
    uuid_pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    if not re.match(uuid_pattern, uuid, re.IGNORECASE):
        return False, f"Неверный формат UUID: {uuid}"
    
    # Проверяем порт
    if not (10001 <= int(port) <= 10100):
        return False, f"Порт должен быть в диапазоне 10001-10100, получен: {port}"
    
    return True, "Формат URL корректен"

def test_required_parameters(url: str) -> tuple[bool, list[str]]:
    """Проверка наличия обязательных параметров"""
    required_params = {
        'type': 'tcp',
        'security': 'reality',
        'encryption': 'none',
        'fp': 'chrome',  # КРИТИЧНО: должен быть chrome для Android совместимости
        'pbk': None,  # Публичный ключ (проверяем наличие)
        'sid': None,  # Short ID (проверяем наличие и длину)
        'sni': None   # SNI (проверяем наличие)
    }
    
    # Извлекаем параметры из URL
    params_match = re.search(r'\?([^#]+)', url)
    if not params_match:
        return False, ["URL не содержит параметров"]
    
    params_str = params_match.group(1)
    params = {}
    for param in params_str.split('&'):
        if '=' in param:
            key, value = param.split('=', 1)
            params[key] = value
    
    missing = []
    errors = []
    
    # Проверяем обязательные параметры
    for param, expected_value in required_params.items():
        if param not in params:
            missing.append(param)
        elif expected_value and params[param] != expected_value:
            errors.append(f"{param} должен быть '{expected_value}', получен '{params[param]}'")
    
    # Проверяем длину short_id (должен быть 8 символов)
    if 'sid' in params:
        sid = params['sid']
        if len(sid) != 8:
            errors.append(f"short_id (sid) должен быть 8 символов, получен {len(sid)}: {sid}")
    
    # Проверяем публичный ключ (должен быть не пустым)
    if 'pbk' in params:
        pbk = params['pbk']
        if not pbk or len(pbk) < 20:
            errors.append(f"Публичный ключ (pbk) слишком короткий: {len(pbk)} символов")
    
    if missing:
        return False, [f"Отсутствуют обязательные параметры: {', '.join(missing)}"]
    if errors:
        return False, errors
    
    return True, ["Все обязательные параметры присутствуют и корректны"]

def test_xray_config_match(uuid: str, url: str) -> tuple[bool, str]:
    """Проверка соответствия конфигурации Xray и генерируемого URL"""
    try:
        # Загружаем конфигурацию Xray
        with open('/root/vpn-server/config/config.json', 'r') as f:
            config = json.load(f)
        
        # Находим inbound для этого ключа
        inbound = None
        for i in config.get('inbounds', []):
            if i.get('protocol') == 'vless':
                clients = i.get('settings', {}).get('clients', [])
                if any(c.get('id') == uuid for c in clients):
                    inbound = i
                    break
        
        if not inbound:
            return False, f"Inbound для ключа {uuid} не найден в конфигурации Xray"
        
        reality_settings = inbound.get('streamSettings', {}).get('realitySettings', {})
        
        # Проверяем fingerprint
        xray_fingerprint = reality_settings.get('fingerprint', '')
        if xray_fingerprint != 'chrome':
            return False, f"Fingerprint в Xray должен быть 'chrome', получен '{xray_fingerprint}'"
        
        # Проверяем short_id
        short_ids = reality_settings.get('shortIds', [])
        if not short_ids:
            return False, "Short IDs не найдены в конфигурации Xray"
        
        # Извлекаем sid из URL
        sid_match = re.search(r'sid=([^&]+)', url)
        if not sid_match:
            return False, "Short ID (sid) не найден в URL"
        
        url_sid = sid_match.group(1)
        if url_sid not in short_ids:
            return False, f"Short ID в URL ({url_sid}) не совпадает с конфигурацией Xray ({short_ids})"
        
        # Проверяем SNI
        sni_match = re.search(r'sni=([^&#]+)', url)
        if sni_match:
            url_sni = sni_match.group(1)
            server_name = reality_settings.get('serverName', '')
            if url_sni != server_name:
                return False, f"SNI в URL ({url_sni}) не совпадает с serverName в Xray ({server_name})"
        
        return True, "Конфигурация Xray и URL совпадают"
    
    except Exception as e:
        return False, f"Ошибка при проверке конфигурации Xray: {e}"

def test_all_keys():
    """Тестирование всех ключей в базе данных"""
    print("=" * 80)
    print("ТЕСТИРОВАНИЕ ГЕНЕРАЦИИ VPN КЛЮЧЕЙ")
    print("=" * 80)
    print()
    
    keys = storage.get_all_keys()
    if not keys:
        print("⚠️  В базе данных нет ключей для тестирования")
        return
    
    print(f"Найдено ключей для тестирования: {len(keys)}\n")
    
    passed = 0
    failed = 0
    errors = []
    
    for key in keys:
        uuid = key.get('uuid')
        name = key.get('name', 'Unknown')
        port = key.get('port')
        
        print(f"Тестирование ключа: {name} ({uuid[:8]}...)")
        print(f"  Порт: {port}")
        
        try:
            # Генерируем URL
            url = generate_client_config(uuid, name, port)
            print(f"  URL: {url[:80]}...")
            
            # Тест 1: Формат URL
            format_ok, format_msg = test_vless_url_format(url)
            if not format_ok:
                print(f"  ❌ Формат URL: {format_msg}")
                failed += 1
                errors.append(f"{name}: {format_msg}")
                continue
            print(f"  ✅ Формат URL: {format_msg}")
            
            # Тест 2: Обязательные параметры
            params_ok, params_msgs = test_required_parameters(url)
            if not params_ok:
                print(f"  ❌ Параметры: {'; '.join(params_msgs)}")
                failed += 1
                errors.append(f"{name}: {'; '.join(params_msgs)}")
                continue
            print(f"  ✅ Параметры: {params_msgs[0]}")
            
            # Тест 3: Соответствие конфигурации Xray
            xray_ok, xray_msg = test_xray_config_match(uuid, url)
            if not xray_ok:
                print(f"  ❌ Конфигурация Xray: {xray_msg}")
                failed += 1
                errors.append(f"{name}: {xray_msg}")
                continue
            print(f"  ✅ Конфигурация Xray: {xray_msg}")
            
            passed += 1
            print()
            
        except Exception as e:
            print(f"  ❌ Ошибка при тестировании: {e}")
            failed += 1
            errors.append(f"{name}: {str(e)}")
            print()
    
    # Итоги
    print("=" * 80)
    print("ИТОГИ ТЕСТИРОВАНИЯ")
    print("=" * 80)
    print(f"✅ Успешно: {passed}")
    print(f"❌ Ошибок: {failed}")
    print(f"📊 Всего: {len(keys)}")
    print()
    
    if errors:
        print("ОШИБКИ:")
        for error in errors:
            print(f"  - {error}")
        print()
        return False
    
    print("✅ Все тесты пройдены успешно!")
    return True

def test_specific_key(uuid: str):
    """Тестирование конкретного ключа"""
    keys = storage.get_all_keys()
    key = next((k for k in keys if k.get('uuid') == uuid), None)
    
    if not key:
        print(f"❌ Ключ {uuid} не найден в базе данных")
        return False
    
    name = key.get('name', 'Unknown')
    port = key.get('port')
    
    print(f"Тестирование ключа: {name} ({uuid})")
    print(f"Порт: {port}\n")
    
    try:
        url = generate_client_config(uuid, name, port)
        print(f"Сгенерированный URL:\n{url}\n")
        
        # Все тесты
        format_ok, format_msg = test_vless_url_format(url)
        print(f"Формат URL: {'✅' if format_ok else '❌'} {format_msg}")
        
        params_ok, params_msgs = test_required_parameters(url)
        print(f"Параметры: {'✅' if params_ok else '❌'} {'; '.join(params_msgs)}")
        
        xray_ok, xray_msg = test_xray_config_match(uuid, url)
        print(f"Конфигурация Xray: {'✅' if xray_ok else '❌'} {xray_msg}")
        
        return format_ok and params_ok and xray_ok
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Тестирование конкретного ключа
        uuid = sys.argv[1]
        success = test_specific_key(uuid)
        sys.exit(0 if success else 1)
    else:
        # Тестирование всех ключей
        success = test_all_keys()
        sys.exit(0 if success else 1)


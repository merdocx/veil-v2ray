#!/usr/bin/env python3
"""
Скрипт для исправления отсутствующего publicKey в конфигурации ключа
"""

import sys
import os
import json

sys.path.insert(0, '/root/vpn-server')

from xray_config_manager import xray_config_manager
from storage.sqlite_storage import storage

def fix_key_publickey(uuid):
    """Исправление publicKey для конкретного ключа"""
    print(f"Исправление publicKey для ключа: {uuid}\n")
    
    # Загружаем Reality ключи
    reality_keys = xray_config_manager._load_reality_keys()
    public_key = reality_keys.get('public_key')
    
    if not public_key:
        print("✗ Ошибка: не найден публичный ключ в keys.env")
        return False
    
    print(f"Публичный ключ из keys.env: {public_key}\n")
    
    # Загружаем конфигурацию
    config = xray_config_manager._load_config()
    if not config:
        print("✗ Ошибка: не удалось загрузить конфигурацию")
        return False
    
    # Ищем inbound для ключа
    found = False
    for inbound in config.get('inbounds', []):
        clients = inbound.get('settings', {}).get('clients', [])
        for client in clients:
            if client.get('id') == uuid:
                found = True
                reality_settings = inbound.get('streamSettings', {}).get('realitySettings', {})
                if reality_settings:
                    old_public_key = reality_settings.get('publicKey', 'N/A')
                    print(f"Текущий publicKey: {old_public_key}")
                    reality_settings['publicKey'] = public_key
                    print(f"Обновлен publicKey: {public_key}")
                break
        if found:
            break
    
    if not found:
        print(f"✗ Ключ {uuid} не найден в конфигурации")
        return False
    
    # Сохраняем конфигурацию
    if xray_config_manager._save_config(config):
        print("\n✓ Конфигурация сохранена")
        
        # Применяем через API
        inbound_tag = f"inbound-{uuid}"
        for inbound in config.get('inbounds', []):
            if inbound.get('tag') == inbound_tag:
                if xray_config_manager._apply_inbound_via_api(inbound):
                    print("✓ Конфигурация применена через Xray API")
                    return True
                else:
                    print("⚠️  Не удалось применить через API, но конфигурация сохранена")
                    return True
        return True
    else:
        print("✗ Ошибка при сохранении конфигурации")
        return False

if __name__ == "__main__":
    # UUID неработающего ключа
    non_working_uuid = "b39a9647-ec86-4c96-ac7c-614e795be3dd"
    
    if fix_key_publickey(non_working_uuid):
        print("\n✓ Ключ исправлен успешно!")
    else:
        print("\n✗ Не удалось исправить ключ")
        sys.exit(1)


#!/usr/bin/env python3
"""
Проверка и исправление неработающего ключа с полным применением конфигурации
"""

import sys
import os
import json

sys.path.insert(0, '/root/vpn-server')

from xray_config_manager import xray_config_manager
from storage.sqlite_storage import storage

def verify_and_fix_key(uuid):
    """Проверка и исправление ключа с полным применением"""
    print(f"Проверка и исправление ключа: {uuid}\n")
    
    # Получаем ключ из БД
    key = storage.get_key_by_identifier(uuid)
    if not key:
        print(f"✗ Ключ {uuid} не найден в БД")
        return False
    
    print(f"Ключ найден: {key.get('name')} (ID: {key.get('id')})")
    print(f"  UUID: {uuid}")
    print(f"  Port: {key.get('port')}")
    print(f"  Short ID: {key.get('short_id')}")
    print(f"  SNI: {key.get('sni')}")
    
    # Загружаем конфигурацию
    config = xray_config_manager._load_config()
    if not config:
        print("✗ Не удалось загрузить конфигурацию")
        return False
    
    # Находим inbound для ключа
    inbound_to_fix = None
    inbound_tag = None
    
    for inbound in config.get('inbounds', []):
        if inbound.get('protocol') != 'vless':
            continue
        clients = inbound.get('settings', {}).get('clients', [])
        for client in clients:
            if client.get('id') == uuid:
                inbound_to_fix = inbound
                inbound_tag = inbound.get('tag')
                break
        if inbound_to_fix:
            break
    
    if not inbound_to_fix:
        print(f"✗ Inbound для ключа {uuid} не найден в конфигурации")
        return False
    
    print(f"\nНайден inbound: {inbound_tag}")
    
    # Проверяем и исправляем Reality settings
    reality_keys = xray_config_manager._load_reality_keys()
    reality_settings = inbound_to_fix.get('streamSettings', {}).get('realitySettings', {})
    
    print("\nПроверка Reality settings:")
    print(f"  Private Key: {'✅' if reality_settings.get('privateKey') == reality_keys.get('private_key') else '❌'}")
    print(f"  Public Key: {'✅' if reality_settings.get('publicKey') == reality_keys.get('public_key') else '❌'}")
    
    # Исправляем если нужно
    fixed = False
    if reality_settings.get('publicKey') != reality_keys.get('public_key'):
        print(f"  ⚠️  Исправление publicKey...")
        reality_settings['publicKey'] = reality_keys.get('public_key')
        fixed = True
    
    if reality_settings.get('privateKey') != reality_keys.get('private_key'):
        print(f"  ⚠️  Исправление privateKey...")
        reality_settings['privateKey'] = reality_keys.get('private_key')
        fixed = True
    
    # Проверяем shortId
    short_id_from_db = key.get('short_id')
    if short_id_from_db and len(short_id_from_db) > 8:
        short_id_from_db = short_id_from_db[:8]
    
    current_short_ids = reality_settings.get('shortIds', [])
    if current_short_ids and current_short_ids[0] != short_id_from_db:
        print(f"  ⚠️  Исправление shortIds...")
        print(f"     Было: {current_short_ids}")
        print(f"     Станет: [{short_id_from_db}]")
        reality_settings['shortIds'] = [short_id_from_db]
        fixed = True
    
    # Проверяем другие параметры
    if reality_settings.get('fingerprint') != 'chrome':
        print(f"  ⚠️  Исправление fingerprint...")
        reality_settings['fingerprint'] = 'chrome'
        fixed = True
    
    if reality_settings.get('serverName') != 'www.microsoft.com':
        print(f"  ⚠️  Исправление serverName...")
        reality_settings['serverName'] = 'www.microsoft.com'
        fixed = True
    
    if not fixed:
        print("  ✅ Все параметры корректны")
    else:
        print("\n💾 Сохранение конфигурации...")
        if not xray_config_manager._save_config(config):
            print("✗ Ошибка при сохранении конфигурации")
            return False
        
        print("✅ Конфигурация сохранена")
        
        print("\n🔄 Применение конфигурации через Xray API...")
        # Удаляем старый inbound
        if inbound_tag:
            print(f"  Удаление старого inbound: {inbound_tag}")
            xray_config_manager._remove_inbound_via_api(inbound_tag)
        
        # Добавляем новый inbound
        print(f"  Добавление нового inbound: {inbound_tag}")
        if xray_config_manager._apply_inbound_via_api(inbound_to_fix):
            print("✅ Конфигурация применена через API")
        else:
            print("⚠️  Не удалось применить через API, но конфигурация сохранена")
            print("   Рекомендуется перезагрузить Xray: systemctl restart xray")
    
    # Выводим финальную конфигурацию
    print("\n" + "="*80)
    print("ФИНАЛЬНАЯ КОНФИГУРАЦИЯ:")
    print("="*80)
    print(f"  Tag: {inbound_to_fix.get('tag')}")
    print(f"  Port: {inbound_to_fix.get('port')}")
    print(f"  Protocol: {inbound_to_fix.get('protocol')}")
    print(f"  Reality Settings:")
    print(f"    - serverName: {reality_settings.get('serverName')}")
    print(f"    - publicKey: {reality_settings.get('publicKey')}")
    print(f"    - privateKey: {reality_settings.get('privateKey', '')[:30]}...")
    print(f"    - shortIds: {reality_settings.get('shortIds')}")
    print(f"    - fingerprint: {reality_settings.get('fingerprint')}")
    
    return True

if __name__ == "__main__":
    uuid = "b39a9647-ec86-4c96-ac7c-614e795be3dd"  # Неработающий ключ
    
    if verify_and_fix_key(uuid):
        print("\n✅ Ключ проверен и исправлен")
        print("\n⚠️  ВАЖНО: Если ключ все еще не работает, перезагрузите Xray:")
        print("   systemctl restart xray")
    else:
        print("\n✗ Произошла ошибка")
        sys.exit(1)


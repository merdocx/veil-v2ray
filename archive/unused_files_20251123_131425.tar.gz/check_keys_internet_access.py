#!/usr/bin/env python3
"""
Скрипт для проверки доступа в интернет для всех VPN ключей
"""

import sys
import os
import json
import subprocess
from datetime import datetime
from typing import Dict, List, Optional

# Добавляем путь к проекту
sys.path.insert(0, '/root/vpn-server')

from storage.sqlite_storage import storage
from xray_stats_reader import get_all_xray_users_traffic, get_xray_user_traffic
from xray_config_manager import xray_config_manager

def check_xray_running() -> bool:
    """Проверка, запущен ли Xray"""
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', 'xray.service'],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.returncode == 0 and result.stdout.strip() == 'active'
    except Exception:
        return False

def get_keys_in_xray_config() -> set:
    """Получить множество UUID ключей, которые есть в конфигурации Xray"""
    try:
        config = xray_config_manager._load_config()
        if not config or 'inbounds' not in config:
            return set()
        
        uuids = set()
        for inbound in config.get('inbounds', []):
            clients = inbound.get('settings', {}).get('clients', [])
            for client in clients:
                if 'id' in client:
                    uuids.add(client['id'])
        
        return uuids
    except Exception as e:
        print(f"Ошибка при чтении конфигурации Xray: {e}")
        return set()

def check_internet_connectivity() -> bool:
    """Проверка базового доступа в интернет сервера"""
    try:
        result = subprocess.run(
            ['ping', '-c', '1', '-W', '2', '8.8.8.8'],
            capture_output=True,
            timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False

def format_bytes(bytes_value: int) -> str:
    """Форматирование байтов в читаемый формат"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_value < 1024.0:
            return f"{bytes_value:.2f} {unit}"
        bytes_value /= 1024.0
    return f"{bytes_value:.2f} PB"

def check_key_internet_access():
    """Основная функция проверки доступа в интернет для всех ключей"""
    
    print("=" * 80)
    print("ПРОВЕРКА ДОСТУПА В ИНТЕРНЕТ ДЛЯ ВСЕХ VPN КЛЮЧЕЙ")
    print("=" * 80)
    print(f"Время проверки: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Проверка базовых условий
    print("1. Проверка базовых условий...")
    xray_running = check_xray_running()
    server_internet = check_internet_connectivity()
    
    print(f"   - Xray сервис: {'✓ Запущен' if xray_running else '✗ Не запущен'}")
    print(f"   - Интернет на сервере: {'✓ Доступен' if server_internet else '✗ Недоступен'}")
    print()
    
    if not xray_running:
        print("⚠️  ВНИМАНИЕ: Xray не запущен. Проверка ключей будет ограничена.")
        print()
    
    if not server_internet:
        print("⚠️  ВНИМАНИЕ: Сервер не имеет доступа в интернет.")
        print()
    
    # Получение всех ключей из базы данных
    print("2. Получение списка ключей из базы данных...")
    try:
        all_keys = storage.get_all_keys()
        print(f"   Найдено ключей: {len(all_keys)}")
    except Exception as e:
        print(f"   ✗ Ошибка при получении ключей: {e}")
        return
    
    if len(all_keys) == 0:
        print("   Нет ключей для проверки.")
        return
    
    print()
    
    # Получение ключей из конфигурации Xray
    print("3. Получение ключей из конфигурации Xray...")
    keys_in_xray = get_keys_in_xray_config()
    print(f"   Ключей в конфигурации Xray: {len(keys_in_xray)}")
    print()
    
    # Получение статистики трафика из Xray
    print("4. Получение статистики трафика из Xray...")
    try:
        if xray_running:
            all_traffic = get_all_xray_users_traffic()
            print(f"   Получена статистика для {len(all_traffic)} активных ключей")
        else:
            all_traffic = {}
            print("   Xray не запущен, статистика недоступна")
    except Exception as e:
        print(f"   ⚠️  Ошибка при получении статистики: {e}")
        all_traffic = {}
    print()
    
    # Анализ каждого ключа
    print("5. Анализ доступа в интернет для каждого ключа:")
    print("=" * 80)
    
    results = {
        'total': len(all_keys),
        'in_xray_config': 0,
        'has_traffic': 0,
        'active': 0,
        'inactive': 0,
        'details': []
    }
    
    for key in all_keys:
        key_uuid = key.get('uuid')
        key_name = key.get('name', 'N/A')
        key_id = key.get('id', 'N/A')
        is_active = key.get('is_active', True)
        port = key.get('port')
        short_id = key.get('short_id', 'N/A')
        
        # Проверка наличия в конфигурации Xray
        in_config = key_uuid in keys_in_xray if key_uuid else False
        
        # Проверка наличия трафика
        has_traffic = False
        traffic_info = None
        if xray_running and key_uuid:
            try:
                traffic = get_xray_user_traffic(key_uuid)
                if traffic and traffic.get('total', 0) > 0:
                    has_traffic = True
                    traffic_info = traffic
            except Exception:
                pass
        
        # Определение статуса доступа в интернет
        # Ключ имеет доступ, если:
        # 1. Он активен в БД
        # 2. Он есть в конфигурации Xray
        # 3. Xray запущен
        # 4. Сервер имеет доступ в интернет
        has_internet = (
            is_active and
            in_config and
            xray_running and
            server_internet
        )
        
        # Дополнительный индикатор - наличие трафика (если был использован)
        if has_traffic:
            has_internet = True  # Если есть трафик, значит точно был доступ
        
        status = "✓ ДОСТУПЕН" if has_internet else "✗ НЕДОСТУПЕН"
        
        # Подсчет статистики
        if in_config:
            results['in_xray_config'] += 1
        if has_traffic:
            results['has_traffic'] += 1
        if has_internet:
            results['active'] += 1
        else:
            results['inactive'] += 1
        
        # Детали для ключа
        key_detail = {
            'id': key_id,
            'name': key_name,
            'uuid': key_uuid[:8] + '...' if key_uuid and len(key_uuid) > 8 else key_uuid,
            'status': status,
            'is_active': is_active,
            'in_xray_config': in_config,
            'has_traffic': has_traffic,
            'port': port,
            'short_id': short_id,
            'traffic': traffic_info
        }
        results['details'].append(key_detail)
        
        # Вывод информации о ключе
        print(f"Ключ: {key_name} (ID: {key_id})")
        print(f"  UUID: {key_uuid[:8] + '...' if key_uuid and len(key_uuid) > 8 else key_uuid}")
        print(f"  Статус: {status}")
        print(f"  Активен в БД: {'✓' if is_active else '✗'}")
        print(f"  В конфигурации Xray: {'✓' if in_config else '✗'}")
        print(f"  Порт: {port if port else 'N/A'}")
        print(f"  Short ID: {short_id}")
        if traffic_info:
            print(f"  Трафик: ↑ {format_bytes(traffic_info.get('uplink', 0))} / ↓ {format_bytes(traffic_info.get('downlink', 0))} / Всего: {format_bytes(traffic_info.get('total', 0))}")
        else:
            print(f"  Трафик: Нет данных")
        
        # Причины недоступности
        if not has_internet:
            reasons = []
            if not is_active:
                reasons.append("Ключ неактивен в БД")
            if not in_config:
                reasons.append("Ключ отсутствует в конфигурации Xray")
            if not xray_running:
                reasons.append("Xray не запущен")
            if not server_internet:
                reasons.append("Сервер не имеет доступа в интернет")
            if reasons:
                print(f"  Причины недоступности: {', '.join(reasons)}")
        
        print()
    
    # Итоговая статистика
    print("=" * 80)
    print("ИТОГОВАЯ СТАТИСТИКА:")
    print("=" * 80)
    print(f"Всего ключей: {results['total']}")
    print(f"  ✓ С доступом в интернет: {results['active']} ({results['active']*100//results['total'] if results['total'] > 0 else 0}%)")
    print(f"  ✗ Без доступа в интернет: {results['inactive']} ({results['inactive']*100//results['total'] if results['total'] > 0 else 0}%)")
    print(f"  В конфигурации Xray: {results['in_xray_config']}")
    print(f"  С трафиком: {results['has_traffic']}")
    print()
    
    # Рекомендации
    if results['inactive'] > 0:
        print("РЕКОМЕНДАЦИИ:")
        print("-" * 80)
        inactive_keys = [k for k in results['details'] if '✗' in k['status']]
        for key in inactive_keys[:10]:  # Показываем первые 10 проблемных ключей
            if not key['is_active']:
                print(f"  • Ключ '{key['name']}' (ID: {key['id']}): активировать в БД")
            elif not key['in_xray_config']:
                print(f"  • Ключ '{key['name']}' (ID: {key['id']}): добавить в конфигурацию Xray")
        if len(inactive_keys) > 10:
            print(f"  ... и еще {len(inactive_keys) - 10} ключей требуют внимания")
        print()
    
    print("=" * 80)
    print("Проверка завершена.")
    print("=" * 80)

if __name__ == "__main__":
    try:
        check_key_internet_access()
    except KeyboardInterrupt:
        print("\n\nПроверка прервана пользователем.")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n✗ Критическая ошибка: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


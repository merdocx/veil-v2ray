# Исправление проблемы с именем в URL

**Дата:** 2025-11-23  
**Проблема:** API возвращает URL без имени ключа (`#name`) в конце

---

## 🔍 Анализ проблемы

### Проблема
- API возвращает: `vless://...@veil-bird.ru:10021?...` (без `#Нидерланды`)
- Скрипт генерирует: `vless://...@veil-bird.ru:10021?...#Нидерланды` (с именем)

### Причина
При вызове `subprocess.run()` в API не была указана кодировка `encoding='utf-8'`, из-за чего кириллические символы в имени ключа могли теряться или обрабатываться неправильно.

---

## ✅ Исправление

**Файл:** `/root/vpn-server/api.py`  
**Функция:** `get_key_config()`  
**Строка:** 527-532

**Было:**
```python
result = subprocess.run([
    '/root/vpn-server/generate_client_config.py',
    key["uuid"],
    key["name"],
    str(port) if port else "443"
], capture_output=True, text=True, check=True)
```

**Стало:**
```python
result = subprocess.run([
    '/root/vpn-server/generate_client_config.py',
    key["uuid"],
    key.get("name", "") or "",  # Убеждаемся, что имя передается
    str(port) if port else "443"
], capture_output=True, text=True, encoding='utf-8', check=True)
```

**Изменения:**
1. ✅ Добавлен `encoding='utf-8'` для правильной обработки кириллицы
2. ✅ Добавлена проверка `key.get("name", "") or ""` для гарантии передачи имени

---

## 🔄 Применение исправления

После исправления необходимо перезапустить API сервис:

```bash
systemctl restart vpn-api
```

---

## ✅ Результат

После исправления API будет возвращать URL с именем ключа:
```
vless://b39a9647-ec86-4c96-ac7c-614e795be3dd@veil-bird.ru:10021?type=tcp&security=reality&encryption=none&fp=chrome&pbk=eeA7CJSPNzlYKqXAsRfFNwtcpG2wXOtgDLPqaXBV13c&sid=8b69ded1&sni=www.microsoft.com#Нидерланды
```

---

**Статус:** ✅ Исправлено, требуется перезапуск API сервиса

